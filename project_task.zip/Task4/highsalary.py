import csv

# open the input file
with open('employee_details.csv', 'r') as salary_details_file:
    # create a CSV reader for the input file
    reader = csv.DictReader(salary_details_file)

    # find the highest salary
    highest_salary = 0
    for row in reader:
        salary = int(row['emp_salary'])
        if salary > highest_salary:
            highest_salary = salary
            highest_salary_emp=row

# print the highest salary
print(highest_salary_emp)
