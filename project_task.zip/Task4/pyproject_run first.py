import csv

# Create the employee personal information CSV file
with open('employee_personal_data.csv', 'w', newline='') as csvfile:
    fieldnames = ['emp_id', 'emp_fullname', 'emp_age', 'emp_gender', 'emp_mobile', 'emp_address', 'emp_email']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    # Add data to the CSV file
    writer.writerow({'emp_id': 101, 'emp_fullname': 'Vinit Jha', 'emp_age': 30, 'emp_gender': 'M', 'emp_mobile': '9834697365', 'emp_address': '23 street bandra', 'emp_email': 'vinit@gmail.com'})
    writer.writerow({'emp_id': 102, 'emp_fullname': 'Krutika Dev', 'emp_age': 27, 'emp_gender': 'F', 'emp_mobile': '8745632109', 'emp_address': '46 Main Street', 'emp_email': 'kruti@gmail.com'})
    writer.writerow({'emp_id': 103, 'emp_fullname': 'Amol Gaikwad', 'emp_age': 22, 'emp_gender': 'M', 'emp_mobile': '9744632109','emp_address': '463 camp Street', 'emp_email': 'amol@gmail.com'})
    writer.writerow({'emp_id': 104, 'emp_fullname': 'Priyanka Shribhate', 'emp_age': 25, 'emp_gender': 'F', 'emp_mobile': '8844632109','emp_address': '13 ram Street', 'emp_email': 'priyanka@gmail.com'})
    writer.writerow({'emp_id': 105, 'emp_fullname': 'Yashjeet Rawale', 'emp_age': 24, 'emp_gender': 'M', 'emp_mobile': '7844632109','emp_address': '321 Shankar nagar Street', 'emp_email': 'yashjeet@gmail.com'})
# Create the employee company details CSV file
with open('employee_company_details.csv', 'w', newline='') as csvfile:
    fieldnames = ['emp_id', 'emp_designation', 'emp_joined', 'emp_status', 'emp_department']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    # Add data to the CSV file
    writer.writerow({'emp_id': 101, 'emp_designation': 'Head Manager', 'emp_joined': '2020-02-02', 'emp_status': 'Active', 'emp_department': 'HR'})
    writer.writerow({'emp_id': 102, 'emp_designation': 'Senior Manager', 'emp_joined': '2022-04-05', 'emp_status': 'Active', 'emp_department': 'Marketing'})
    writer.writerow({'emp_id': 103, 'emp_designation': 'Traniee', 'emp_joined': '2022-06-05', 'emp_status': 'Active','emp_department': 'HR'})
    writer.writerow({'emp_id': 104, 'emp_designation': 'Manager', 'emp_joined': '2022-08-02', 'emp_status': 'Active','emp_department': 'Sales'})
    writer.writerow({'emp_id': 105, 'emp_designation': 'Analyst', 'emp_joined': '2022-03-02', 'emp_status': 'Active','emp_department': 'HR'})
# Create the employee salary details CSV file
with open('employee_salary_details.csv', 'w', newline='') as csvfile:
    fieldnames = ['emp_id', 'emp_salary', 'emp_net_salary', 'emp_tax', 'emp_pf', 'emp_health_amount']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    # Add data to the CSV file
    writer.writerow({'emp_id': 101, 'emp_salary': 60000, 'emp_net_salary': 720000, 'emp_tax': 10000, 'emp_pf': 2000, 'emp_health_amount': 1000})
    writer.writerow({'emp_id': 102, 'emp_salary': 50000, 'emp_net_salary': 600000, 'emp_tax': 5000, 'emp_pf': 1500, 'emp_health_amount': 500})
    writer.writerow({'emp_id': 103, 'emp_salary': 30000, 'emp_net_salary': 360000, 'emp_tax': 900, 'emp_pf': 500,'emp_health_amount': 300})
    writer.writerow({'emp_id': 104, 'emp_salary': 40000, 'emp_net_salary': 400000, 'emp_tax': 1000, 'emp_pf': 700,'emp_health_amount': 350})
    writer.writerow({'emp_id': 105, 'emp_salary': 45000, 'emp_net_salary': 540000, 'emp_tax': 1500, 'emp_pf': 800,'emp_health_amount': 400})
# Merge the three CSV files into a single employee details CSV file

